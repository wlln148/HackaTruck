//
//  SaveMoneyApp.swift
//  SaveMoney
//
//  Created by Student02 on 26/09/23.
//

import SwiftUI

@main
struct SaveMoneyApp: App {
    var body: some Scene {
        WindowGroup {
            Validacao()
        }
    }
}
